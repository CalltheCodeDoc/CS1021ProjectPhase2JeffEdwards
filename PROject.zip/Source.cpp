#include <iostream>
#include <string>


using namespace std;



//**************************************************************************
//must do flow chart
//**************************************************************************



int main()
{
    //arrays or vectors?? think vectors will be better cause they are variable size
    //for customer information

    //or we can create a customer class
    //and store an array of customer classes
    /*int CID[];
    string Username[];
    string Name[];
    string AccType[];
    string Org[];
    string Status[];
    string DOB[];
    string DOJ[];
    long SSN[];
    string Password[];
    */





    //can basically put all this crap in functions and just
    // create a looping structure that passes keys of success or failure that signify
    //  what next step to loop through


    //main menu


    char first_page_option;

    string admin_user;
    string admin_pass;
    bool match;
    bool cusmatch;

    string customer_or_admin;
    //or
    bool admin_success;
    bool customer_success;


    int CID;
    string Username;
    string Name;
    string AccType;
    string Org;
    string Status;
    string DOB;
    string DOJ;
    long SSN;
    string Password;



    do {
        system("clear");
        cout << "************WelcometoC++ProgrammersBank*********************" << endl;
        cout << "1. AdminSignIn: ����Enter1����" << endl;
        cout << "2. CustomerSignInpage:����Enter2����" << endl;
        cout << "3. CustomerSignUppage:����Enter3����" << endl;
        cout << "4. ExitApplication:����Enter4����" << endl << endl;
        cout << "Enter your option: " << endl;
        cin >> first_page_option;
        cin.ignore();

        //should do functions for a lot of this functionality
        //any code thats repeatd or looped through can be put in a function really


        //this below should be outside loop
        do {
            system("clear");
            cout << "" << endl;
            cout << "" << endl;
            cout << "" << endl;
            cout << "" << endl;
            cout << "" << endl;




        } while (false);
    } while (first_page_option != 1 && first_page_option != 2 && first_page_option != 3 && first_page_option != 4);

    switch (first_page_option)
    {
    
        case 1:
            do {
                system("clear");
                cout << "AdminSignInPage:" << endl << endl;
                cout << "Enter Admin Username: " << endl;
                cout << "Enter Password: " << endl << endl;
                if (match) {
                    cout << "******PasswordMatch: Proceed**********" << endl << endl;

                }
                else {
                    cout << "******Passwordmismatch: LoopBack*********" << endl << endl;
                }
            } while (false);
        case 2:
            do {
                system("clear");
                cout << "Customer Sign in Page:" << endl << endl;
                cout << "Enter Customer Username: " << endl;
                cout << "Enter Password: " << endl << endl;
                if (cusmatch) {
                    cout << "******PasswordMatch: Proceed**********" << endl << endl;

                }
                else {
                    cout << "******Passwordmismatch: LoopBack*********" << endl << endl;
                }
            } while (false);
        case 3:
            do {
                system("clear");
                //cout << "Customer Sign Up Page:" << endl << endl;
               // cout << "Enter Customer Username: " << endl;
                //cout << "Enter Username: " << endl << endl;
                //cin >> int CID;                                   //must determine customer id
                //cin.ignore();
                cout << "Enter Customer Username: " << endl;
                cin >> string Username;
                cin.ignore();
                cout << "Enter Name: " << endl;
                cin >> string Name;
                cin.ignore();
                cout << "Enter Account Type(B/P): " << endl;
                cin >> string AccType;
                cin.ignore();
                cout << "Enter Organization: " << endl;
                cin >> string Org;
                cin.ignore();
                //cout << "Enter DOB: " << endl;
                //cin >> string Status;                //<<set by bank
                //cin.ignore();
                cout << "Enter Date of Birth: " << endl;
                cin >> string DOB;
                cin.ignore();
                //cout << "Enter Date of Join: " << endl;
                //cin >> string DOJ;                  //set to current date
                //cin.ignore();
                cout << "Enter Social Security Number: " << endl;
                cin >> long SSN;
                cin.ignore();
                cout << "Enter Password: " << endl;
                cin >> string Password;
                cin.ignore();
                //add to a customer array like lab project, just add another customer
                //should be searchable somehow
                //this is where u would create a new customer object jsut like shelf class types
            } while (false);
        case 4:
            cout << "wha" << endl;
        default:
            cout << "uhoh" << endl;
}


    switch (customer_or_admin)
    {
    case "admin":
        cout << "Adminfunctionality : " << endl;
        cout << "1 : PayMonthlyInterest." << endl;
        cout << "2 : Checkaccountwith - vebalance." << endl;
        cout << "3. Checkaccountwith + vebalances." << endl;
        cout << "4 : Warningmessagesto - vebalanceaccounts." << endl;
        cout << "5 : Repeated - vebalance; Blockaccount." << endl;
        cout << "6: GeneratesummaryReport:" << endl;
        cout << setw(20) << "� TotalCustomers�" << endl;
        cout << setw(20) << "� Totalactivecustomers�" << endl;
        cout << setw(20) << " � TotalInactivecustomers�" << endl;
        cout << setw(20) << "� Total + vebalances�" << endl;
        cout << setw(20) << "� Total - vebalances�" << endl;
        cout<<"7: Logout" << endl;
    case "customer":
        cout << "CustomerFunctionality:" << endl;
        cout << "1: StatementsummarylastNtransactions:" << endl;
        cout << "2: CurrentBalance" << endl;
        cout << "3. Withdraw" << endl;
        cout << "4: Deposit" << endl;
        cout << "5: TransfertootherCID" << endl;
        cout << "6: CheckInbox" << endl;
        cout << "7: Logout" << endl;
    default:
        cout << "uhoh" << endl;
    }

    return 0;
}

