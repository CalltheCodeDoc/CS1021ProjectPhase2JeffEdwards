#pragma once
#ifndef CUSTOMER_H
#define CUSTOMER_H
#include <string>
#include <vector>

using namespace std;

class Customer {

private:
    int CID;
    string Username;
    string Name;
    string AccType;
    string Org;
    string Status;
    string DOB;
    string DOJ;
    long SSN;
    string Password;

    // uh oh these tables can't just be
    vector<long> account_status;     // a table of transactions
    long current_balance;     //sum of all transactions

	public:
		//constructors
		Customer();
        Customer(int id, string user, string nam, string acc, string organ, string stat, string birth, string job, long social, string pass);
		~Customer();

        //mutators
        void transaction(long credit_debit);    //addjusts account_status by adding a new negative
        // or positive entry
        //accessors
        long balance();  // returns current balance or a transaction from account_status vector
};

#endif